# Individual Lab 4 — Scheduling & Flight Plan

This reads satellite passes from `input_passes.json`, filters out invalid passes like where the end time is before the start time. Then it schedules up to a maximum number of non-overlapping passes, and writes the result to `flight_plan.json`.

## Files

### `input_passes.json`
Input file containing the satellite, date, and a list of possible passes.

```json
{
  "satellite_id": "Sentinel-1A",
  "date": "2026-02-18",
  "passes": [
    {
      "pass_id": "P1",
      "start_time": "2026-02-18T05:30:00Z",
      "end_time": "2026-02-18T05:42:00Z"
    },
    {
      "pass_id": "P2",
      "start_time": "2026-02-18T06:00:00Z",
      "end_time": "2026-02-18T06:05:00Z"
    },
    {
      "pass_id": "P3",
      "start_time": "2026-02-18T06:10:00Z",
      "end_time": "2026-02-18T06:25:00Z"
    },
    {
      "pass_id": "P4",
      "start_time": "2026-02-18T06:20:00Z",
      "end_time": "2026-02-18T06:35:00Z"
    },
    {
      "pass_id": "P5",
      "start_time": "2026-02-18T07:00:00Z",
      "end_time": "2026-02-18T07:15:00Z"
    },
    {
      "pass_id": "P6",
      "start_time": "2026-02-18T15:00:00Z",
      "end_time": "2026-02-18T15:20:00Z"
    }
  ]
}
```

### `flight_plan.json`
Output file containing the scheduled passes sorted by greedy "Earliest start time first".

```json
{
  "satellite_id": "Sentinel-1A",
  "date": "2026-02-18",
  "scheduled_passes": [
    {
      "pass_id": "P1",
      "start_time": "2026-02-18T05:30:00Z",
      "end_time": "2026-02-18T05:42:00Z"
    },
    {
      "pass_id": "P3",
      "start_time": "2026-02-18T06:10:00Z",
      "end_time": "2026-02-18T06:25:00Z"
    },
    {
      "pass_id": "P5",
      "start_time": "2026-02-18T07:00:00Z",
      "end_time": "2026-02-18T07:15:00Z"
    }
  ]
}
```

Where P2 is excluded because the time window is under 8 minutes, and P4 is excluded because it overlaps with P3. P6 is excluded because it starts after the maximum number of passes (3) has been reached.